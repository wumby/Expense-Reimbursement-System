package com.revature.exception;

    public class ImageNotFoundException extends Exception {
        public ImageNotFoundException(String message) {
            super(message);
        }
}
