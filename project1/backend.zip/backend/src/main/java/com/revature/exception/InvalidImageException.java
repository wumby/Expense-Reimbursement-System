package com.revature.exception;

public class InvalidImageException extends Exception{
    public InvalidImageException(String message){
        super(message);
    }

}
